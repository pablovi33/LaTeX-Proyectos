vhdl-simple-processor
=====================

Implementation of a simple processor using VHDL for logic synthesis in FPGA
