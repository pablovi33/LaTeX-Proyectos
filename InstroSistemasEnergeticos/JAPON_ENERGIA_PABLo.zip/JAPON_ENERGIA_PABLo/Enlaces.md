

Cabinet Decision on the New Strategic Energy Plan
https://www.meti.go.jp/english/press/2018/0703_002.html

Joint Statement on Japan-United states Strategic Energy Partnership
https://www.enecho.meti.go.jp/en/category/others/jusep/

Comision de energia y gas
https://www.emsc.meti.go.jp/english/

Fotovoltaico en japon
https://www.meti.go.jp/english/policy/energy_environment/renewable/ref2001.html

Renovable en japon
https://www.meti.go.jp/english/policy/energy_environment/renewable/index.html

Energia japon

https://criepi.denken.or.jp/en/

Japon nuclear

https://www.jaea.go.jp/english/index.html

Desperdicio nuclear

https://www.rwmc.or.jp/english/