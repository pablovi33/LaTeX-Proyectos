% Proyecto Energia Japon
% Pablo Vivar Colina
% Marzo 2019

# Introduccion

El objetivo del escrito que se presenta a continuación es mostrar un resumen de los diferentes medios energéticos que se encuentran disponibles en Japón actualmente.

Para ello se describirá su organización y distribución, cuales son los principales tipos de producción de energía eléctrica.

## Ejemplos sitaxis de MARKDOWN

*ejemplo de cursiva*

**ejemplo de negrita**

* itemize 1
* itemize 2

>  Ejemplo de citas largas

Si tenemos un texto con una nota es [^nota]



Para citar con refernecias por ejemplo algo de Openscad. [@OpenSCS,p. 35]

## Recursos Naturales de Japon

# Fuentes Convencionales de Energia

## Carbon

## Petroleo

## Gas

# Fuentes Renovables de energia

## Solar

## Eolica

## Hidraulica



# Energia Nuclear

# Oferta y Demanda de Electricidad en Japon

# Referencias



[^nota]: Esto es una nota
